var content=(function(){function e(e){return e}var t=/\$|€|£|¥|元|订阅|subscribe|renewal|charge|payment|fee|price|促销|优惠/i,n=[/no\s*thanks?,\s*i\s*(hate|don'?t|love paying|prefer not)/i,/no\s*thanks?,\s*i\s*(don'?t want|don'?t need)/i,/i\s*don'?t\s*(want|need)\s*(to\s*)?(save|discount|deal|offer)/i,/i\s*(love|prefer)\s*(paying|spending)\s*more/i],r=[/不了[，,]?\s*我不需要省/,/不了[，,]?\s*我不想/,/不了[，,]?\s*我不要优惠/,/放弃(优惠|折扣|省钱)/],i=/cancel|unsubscribe|退订|取消订阅|不续费/i;function a(e){return typeof CSS<`u`&&CSS.escape?CSS.escape(e):e.replace(/([^\w-])/g,`\\$1`)}function o(e){if(e.id)return`#${a(e.id)}`;let t=e.tagName.toLowerCase(),n=Array.from(e.classList).slice(0,2).map(e=>`.${a(e)}`).join(``);return n?`${t}${n}`:t}function s(e){let n=[],r=e.querySelectorAll(`input[type="checkbox"][checked]`);for(let i of r){let r=``,a=i.id;if(a){let t=e.querySelector(`label[for="${a}"]`);t&&(r=t.textContent||``)}let s=i.parentElement?.textContent||``,c=r+s;t.test(c)&&n.push({type:`预勾选订阅`,element:o(i),description:`预先勾选的订阅/付费选项：${c.trim().slice(0,60)}`})}return n}function c(e){let t=[],i=e.querySelectorAll(`button, a, [role="button"]`);for(let e of i){let i=e.textContent?.trim()||``;i&&(n.some(e=>e.test(i))||r.some(e=>e.test(i)))&&t.push({type:`羞辱式按钮`,element:o(e),description:`羞辱式拒绝选项：${i.slice(0,80)}`})}return t}function l(e){let t=[],n=e.querySelectorAll(`[class*="countdown"],[class*="timer"],[class*="clock"],[id*="countdown"],[id*="timer"]`);for(let e of n)t.push({type:`虚假倒计时`,element:o(e),description:`倒计时元素可能制造虚假紧迫感：${(e.textContent||``).trim().slice(0,60)}`});return t}function u(e){let t=[],n=e.querySelectorAll(`a, button`);for(let e of n){let n=e.textContent?.trim()||``;if(!i.test(n))continue;let r=e.getAttribute(`style`)||``;(/opacity\s*:\s*0\.[0-2]/i.test(r)||/font-size\s*:\s*[0-9]px(?!\d)/i.test(r)||/color\s*:\s*#[fF]{6}/i.test(r)||/color\s*:\s*white/i.test(r)||/display\s*:\s*none/i.test(r)||/visibility\s*:\s*hidden/i.test(r))&&t.push({type:`隐藏取消选项`,element:o(e),description:`取消/退订链接被刻意隐藏：${n.slice(0,60)}`})}return t}function d(e){return[...s(e),...c(e),...l(e),...u(e)]}var f=[];function p(){return d(document)}function m(e,t){for(let e of f)e.style.outline=``,e.style.outlineOffset=``;if(f.length=0,e)for(let e of t)try{let t=e.element.replace(/<[^>]+>/g,``).trim()||e.element,n=t.includes(`<`)?`*`:t,r=document.querySelectorAll(n);for(let e of r)e.style.outline=`3px solid #ef4444`,e.style.outlineOffset=`2px`,f.push(e)}catch{}}function h(){let e=[],t=document.querySelectorAll(`*`);for(let n of t){let t=n.tagName.toLowerCase();if([`script`,`style`,`meta`,`link`,`head`,`html`,`body`,`noscript`].includes(t))continue;let r=window.getComputedStyle(n),i=n.getBoundingClientRect(),a=``;if(r.display===`none`?a=`display:none`:r.visibility===`hidden`?a=`visibility:hidden`:parseFloat(r.opacity)===0?a=`opacity:0`:i.width>0&&i.height>0&&(i.right<0||i.bottom<0||i.left>window.innerWidth||i.top>window.innerHeight)&&(a=`移出视口`),!a)continue;let o=n.textContent?.trim()||``;if(!o&&!n.querySelector(`img,input,button`))continue;let s=g(n);e.push({selector:s,reason:a,contentPreview:o.slice(0,60)||`<${t}>`,tagName:t})}return e.slice(0,50)}function g(e){if(e.id)return`#${CSS.escape(e.id)}`;let t=e.tagName.toLowerCase(),n=Array.from(e.classList).slice(0,2).map(e=>`.${CSS.escape(e)}`).join(``);return n?`${t}${n}`:t}function _(e){return e>=70?`#22c55e`:e>=40?`#eab308`:`#ef4444`}var v=null,y=null,b=null;function x(){if(document.getElementById(`__veil_ball__`))return;v=document.createElement(`div`),v.id=`__veil_ball__`,v.style.cssText=`position:fixed;bottom:28px;right:20px;z-index:2147483647;cursor:pointer;`;let e=v.attachShadow({mode:`open`});e.innerHTML=`
    <style>
      .wrap { position: relative; }
      .ball {
        width: 52px; height: 52px;
        border-radius: 50%;
        background: rgba(255,255,255,0.92);
        backdrop-filter: blur(20px) saturate(1.8);
        -webkit-backdrop-filter: blur(20px) saturate(1.8);
        display: flex; align-items: center; justify-content: center;
        box-shadow: 0 4px 20px rgba(0,0,0,0.15), 0 1px 4px rgba(0,0,0,0.08), inset 0 1px 0 rgba(255,255,255,0.9);
        transition: transform 0.15s ease, box-shadow 0.15s ease;
        user-select: none; cursor: pointer;
        position: relative;
      }
      .ball:hover {
        transform: scale(1.06);
        box-shadow: 0 8px 28px rgba(0,0,0,0.18), 0 2px 6px rgba(0,0,0,0.1), inset 0 1px 0 rgba(255,255,255,0.9);
      }
      .ball:active { transform: scale(0.94); }
      .ring-svg {
        position: absolute; top: 0; left: 0;
        width: 52px; height: 52px;
        transform: rotate(-90deg);
        pointer-events: none;
      }
      .ring-bg { fill: none; stroke: rgba(0,0,0,0.06); stroke-width: 3; }
      .ring-fg { fill: none; stroke-width: 3; stroke-linecap: round; transition: stroke-dashoffset 0.5s ease, stroke 0.4s ease; }
      .score-text {
        font: 600 14px/1 -apple-system, sans-serif;
        color: #1C1C1E;
        position: relative; z-index: 1;
        letter-spacing: -0.5px;
      }
      .tip {
        position: absolute; bottom: 60px; right: 0;
        background: rgba(28,28,30,0.92);
        backdrop-filter: blur(16px);
        -webkit-backdrop-filter: blur(16px);
        color: #fff;
        font: 12px/1.5 -apple-system, sans-serif;
        white-space: nowrap;
        padding: 8px 12px; border-radius: 10px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.3);
        opacity: 0; transition: opacity 0.2s; pointer-events: none;
      }
      .tip::after {
        content:''; position:absolute; bottom:-5px; right:18px;
        border:5px solid transparent; border-top-color:rgba(28,28,30,0.92); border-bottom:none;
      }
    </style>
    <div class="wrap">
      <div class="ball" id="ball">
        <svg class="ring-svg" viewBox="0 0 52 52">
          <circle class="ring-bg" cx="26" cy="26" r="22"/>
          <circle class="ring-fg" id="ring" cx="26" cy="26" r="22"
            stroke="#34C759"
            stroke-dasharray="138.23"
            stroke-dashoffset="0"/>
        </svg>
        <span class="score-text" id="score">100</span>
      </div>
      <div class="tip" id="tip">点击右上角 <b>V</b> 图标打开面板<br>或右键网页选「Open Veil」</div>
    </div>
  `,y=e.getElementById(`score`),b=e.getElementById(`ring`),e.getElementById(`ball`)?.addEventListener(`click`,()=>{let t=e.getElementById(`tip`);t&&(t.style.opacity=`1`,setTimeout(()=>{t.style.opacity=`0`},3e3))}),document.body.appendChild(v)}function S(e){if(!y)return;y.textContent=String(e);let t=_(e);if(b){let n=2*Math.PI*22;b.style.stroke=t,b.style.strokeDashoffset=String(n*(1-e/100))}}var C=null;function w(e){T(),C=document.createElement(`div`),C.id=`__veil_xray__`,C.style.cssText=`position:fixed;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:2147483646;`,document.body.appendChild(C);for(let t of e)try{let e=document.querySelector(t.selector);if(!e)continue;let n=e.getBoundingClientRect(),r=document.createElement(`div`);r.style.cssText=[`position:fixed`,`top:${n.top}px`,`left:${n.left}px`,`width:${Math.max(n.width,20)}px`,`height:${Math.max(n.height,20)}px`,`background:rgba(175,82,222,0.18)`,`border:2px solid #AF52DE`,`border-radius:2px`,`box-sizing:border-box`,`pointer-events:none`].join(`;`);let i=document.createElement(`div`);i.style.cssText=`position:absolute;top:0;left:0;background:#1e1e2e;color:#fff;font-size:11px;padding:2px 6px;border-radius:2px;white-space:nowrap;max-width:200px;overflow:hidden;text-overflow:ellipsis;`,i.textContent=`${t.tagName} · ${t.reason}`,r.appendChild(i),C.appendChild(r)}catch{}}function T(){C?.remove(),C=null,document.getElementById(`__veil_xray__`)?.remove()}var E=e({matches:[`<all_urls>`],main(){if(!document.body)return;x();let e=[],t=[],n=()=>{e=p(),t=h(),chrome.runtime.sendMessage({type:`DARK_PATTERNS_RESULT`,patterns:e}),chrome.runtime.sendMessage({type:`HIDDEN_ELEMENTS_RESULT`,elements:t})};document.readyState===`complete`?n():window.addEventListener(`load`,n,{once:!0}),chrome.runtime.onMessage.addListener((n,r,i)=>{switch(n.type){case`SCORE_UPDATE`:S(n.data.total);return;case`SCAN_DARK_PATTERNS`:return e=p(),i({patterns:e}),!0;case`SCAN_HIDDEN_ELEMENTS`:return t=h(),i({elements:t}),!0;case`TOGGLE_HIGHLIGHT`:m(n.enabled,e);return;case`TOGGLE_XRAY`:n.enabled?w(t):T();return;case`LOCATE_ELEMENT`:try{document.querySelector(n.selector)?.scrollIntoView({behavior:`smooth`,block:`center`})}catch{}return}})}}),D={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)},O=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome,k=class e extends Event{static EVENT_NAME=A(`wxt:locationchange`);constructor(t,n){super(e.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=n}};function A(e){return`${O?.runtime?.id}:content:${e}`}var j=typeof globalThis.navigation?.addEventListener==`function`;function M(e){let t,n=!1;return{run(){n||(n=!0,t=new URL(location.href),j?globalThis.navigation.addEventListener(`navigate`,e=>{let n=new URL(e.destination.url);n.href!==t.href&&(window.dispatchEvent(new k(n,t)),t=n)},{signal:e.signal}):e.setInterval(()=>{let e=new URL(location.href);e.href!==t.href&&(window.dispatchEvent(new k(e,t)),t=e)},1e3))}}}var N=class e{static SCRIPT_STARTED_MESSAGE_TYPE=A(`wxt:content-script-started`);id;abortController;locationWatcher=M(this);constructor(e,t){this.contentScriptName=e,this.options=t,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return O.runtime?.id??this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener(`abort`,e),()=>this.signal.removeEventListener(`abort`,e)}block(){return new Promise(()=>{})}setInterval(e,t){let n=setInterval(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(e,t){let n=setTimeout(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(e){let t=requestAnimationFrame((...t)=>{this.isValid&&e(...t)});return this.onInvalidated(()=>cancelAnimationFrame(t)),t}requestIdleCallback(e,t){let n=requestIdleCallback((...t)=>{this.signal.aborted||e(...t)},t);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(e,t,n,r){t===`wxt:locationchange`&&this.isValid&&this.locationWatcher.run(),e.addEventListener?.(t.startsWith(`wxt:`)?A(t):t,n,{...r,signal:this.signal})}notifyInvalidated(){this.abort(`Content script context invalidated`),D.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){document.dispatchEvent(new CustomEvent(e.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),this.options?.noScriptStartedPostMessage||window.postMessage({type:e.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},`*`)}verifyScriptStartedEvent(e){let t=e.detail?.contentScriptName===this.contentScriptName,n=e.detail?.messageId===this.id;return t&&!n}listenForNewerScripts(){let t=e=>{!(e instanceof CustomEvent)||!this.verifyScriptStartedEvent(e)||this.notifyInvalidated()};document.addEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t),this.onInvalidated(()=>document.removeEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t))}},P={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)};return(async()=>{try{let{main:e,...t}=E;return await e(new N(`content`,t))}catch(e){throw P.error(`The content script "content" crashed on startup!`,e),e}})()})();
content;